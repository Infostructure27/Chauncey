<div id="map"  style="min-height: 300px" class="<?php print $classes; ?>" <?php print $attributes; ?>>
</div>